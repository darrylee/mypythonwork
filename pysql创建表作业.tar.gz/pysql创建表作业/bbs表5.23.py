import pymysql

conn = pymysql.Connect(host='192.168.108.136',user='root',
                     password='li199010',db='bbs',port=3306,charset='utf8')

cursor = conn.cursor(cursor=pymysql.cursors.DictCursor)

sql="""
create table if not exists user (uid int primary key auto_increment,usertype enum('0','1') default '0',password char(40) not null,regtime date not null,email varchar(100) not null)default charset=utf8;
"""
res = cursor.execute(sql)

cursor.close()
conn.close()