import pymysql

conn = pymysql.Connect(host='192.168.108.137',user='root',password='li199010',db='bbs',port=3306,charset='utf8')

cursor = conn.cursor(cursor=pymysql.cursors.DictCursor)

while True:
        in_name = input("请输入用户名：")
        in_password = input("请输入密码：")
        sql = "select username from user where username='%s' and password=sha1('%s')"%(in_name,in_password)
        res = cursor.execute(sql)
        if not res:
            print("密码或用户名错误，请重新输入！")
        else:
            print("登录成功！")
        break
cursor.close()
conn.close()