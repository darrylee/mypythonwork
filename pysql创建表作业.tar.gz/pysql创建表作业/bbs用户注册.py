import pymysql

# 创建数据库连接
conn = pymysql.Connect(host='192.168.108.137',user='root',password='li199010',db='bbs',port=3306,charset='utf8')

# 创建游标获取cursor对象
cursor = conn.cursor(cursor=pymysql.cursors.DictCursor)

# 执行mysql语句
in_name = input("输入用户名：")

sql = "select username from user where username='%s'"%in_name
# 返回值是受影响行数

res1 = cursor.execute(sql)

if not res1:
    if len(in_name.strip())<=2:
        print("请重新输入用户名")
    else:
        in_password = input("输入用户密码：")
        in_email=input("请输入邮箱号：")
        sql1 = """
        insert into user(username,password,regtime,email) values('%s',sha1('%s'),date(now()),'%s');
        """ % (in_name, in_password, in_email)
        res=cursor.execute(sql1)
        if res:
            conn.commit()
        else:
            conn.rollback()
else:
    print("用户存在")

