# 数据库连接的配置文件
parameters = {
    'host':'192.168.108.136',
    'user':'root',
    'password':'li199010',
    'port':3306,
    'charset':'utf8',
    'database':'student02'
}